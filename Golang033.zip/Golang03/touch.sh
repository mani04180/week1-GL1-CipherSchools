git init
git remote add origin https://github.com/Suryaakula888/Week3-GL1-CipherSchools.git
git remote -v  --force
git add . --force
git commit -m "april_2nd_upload"


git push -f origin master
